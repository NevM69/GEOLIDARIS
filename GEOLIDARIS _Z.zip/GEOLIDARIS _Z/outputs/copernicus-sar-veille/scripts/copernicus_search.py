#!/usr/bin/env python3
"""
Recherche automatisée d'acquisitions Copernicus (Sentinel-1/2) sur une zone
d'intérêt, via l'API STAC publique du Copernicus Data Space Ecosystem.
Aucune authentification requise. Compte gratuit nécessaire uniquement pour
télécharger les produits complets.

Usage :
  # Autour d'un point (rayon en km), Sentinel-2, nuages < 30 %
  python3 copernicus_search.py --lat 44.92 --lon 6.36 --radius 8 \
      --from 2026-06-01 --to 2026-07-09 --collection s2 --max-cloud 30

  # Sur une bbox, Sentinel-1 (radar, tout-temps)
  python3 copernicus_search.py --bbox 6.2,44.85,6.5,45.0 \
      --from 2026-06-01 --to 2026-07-09 --collection s1

  # Mode veille : uniquement les images publiées depuis N jours
  python3 copernicus_search.py --lat 44.92 --lon 6.36 --radius 8 \
      --since-days 5 --collection s2

Sortie : tableau texte + JSON (--json out.json) avec, pour chaque image :
date, couverture nuageuse, identifiant produit, lien quicklook et lien direct
Copernicus Browser prêt à ouvrir (True Color et False Color).
"""

import argparse
import json
import math
import sys
import urllib.request
import urllib.parse
from datetime import datetime, timedelta, timezone

STAC_SEARCH = "https://stac.dataspace.copernicus.eu/v1/search"
COLLECTIONS = {"s2": "sentinel-2-l2a", "s1": "sentinel-1-grd"}
BROWSER = "https://browser.dataspace.copernicus.eu/"


def bbox_around(lat, lon, radius_km):
    dlat = radius_km / 111.32
    dlon = radius_km / (111.32 * max(math.cos(math.radians(lat)), 0.01))
    return [lon - dlon, lat - dlat, lon + dlon, lat + dlat]


def browser_link(lat, lon, date, dataset, layer):
    params = {
        "zoom": "13",
        "lat": f"{lat:.5f}",
        "lng": f"{lon:.5f}",
        "themeId": "DEFAULT-THEME",
        "datasetId": dataset,
        "fromTime": f"{date}T00:00:00.000Z",
        "toTime": f"{date}T23:59:59.999Z",
        "layerId": layer,
    }
    return BROWSER + "?" + urllib.parse.urlencode(params)


def stac_search(bbox, dt_from, dt_to, collection, max_cloud, limit=200):
    body = {
        "collections": [collection],
        "bbox": bbox,
        "datetime": f"{dt_from}T00:00:00Z/{dt_to}T23:59:59Z",
        "limit": min(limit, 200),
    }
    if collection.startswith("sentinel-2") and max_cloud is not None:
        body["filter"] = {
            "op": "<=",
            "args": [{"property": "eo:cloud_cover"}, max_cloud],
        }
        body["filter-lang"] = "cql2-json"
    req = urllib.request.Request(
        STAC_SEARCH,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json",
                 "User-Agent": "ong-sar-veille/1.0"},
    )
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)["features"]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--lat", type=float)
    p.add_argument("--lon", type=float)
    p.add_argument("--radius", type=float, default=8.0, help="rayon km")
    p.add_argument("--bbox", help="lonmin,latmin,lonmax,latmax")
    p.add_argument("--from", dest="dt_from", help="AAAA-MM-JJ")
    p.add_argument("--to", dest="dt_to", help="AAAA-MM-JJ")
    p.add_argument("--since-days", type=int,
                   help="mode veille : N derniers jours")
    p.add_argument("--collection", choices=["s2", "s1"], default="s2")
    p.add_argument("--max-cloud", type=float, default=40.0)
    p.add_argument("--json", dest="json_out", help="fichier JSON de sortie")
    a = p.parse_args()

    if a.bbox:
        bbox = [float(x) for x in a.bbox.split(",")]
        clat, clon = (bbox[1] + bbox[3]) / 2, (bbox[0] + bbox[2]) / 2
    elif a.lat is not None and a.lon is not None:
        bbox = bbox_around(a.lat, a.lon, a.radius)
        clat, clon = a.lat, a.lon
    else:
        sys.exit("Indiquez --lat/--lon ou --bbox")

    if a.since_days:
        a.dt_to = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        a.dt_from = (datetime.now(timezone.utc)
                     - timedelta(days=a.since_days)).strftime("%Y-%m-%d")
    if not (a.dt_from and a.dt_to):
        sys.exit("Indiquez --from/--to ou --since-days")

    coll = COLLECTIONS[a.collection]
    feats = stac_search(bbox, a.dt_from, a.dt_to, coll,
                        a.max_cloud if a.collection == "s2" else None)
    feats.sort(key=lambda f: f["properties"]["datetime"])

    dataset = "S2_L2A_CDSE" if a.collection == "s2" else "S1_CDAS_IW_VVVH"
    results = []
    for f in feats:
        pr = f["properties"]
        date = pr["datetime"][:10]
        row = {
            "date": pr["datetime"][:16].replace("T", " "),
            "produit": f["id"],
            "nuages_pct": pr.get("eo:cloud_cover"),
            "quicklook": (f.get("assets", {}).get("thumbnail", {})
                          .get("href")),
            "browser_true_color": browser_link(clat, clon, date, dataset,
                                               "1_TRUE_COLOR"),
        }
        if a.collection == "s2":
            row["browser_false_color"] = browser_link(
                clat, clon, date, dataset, "2_FALSE_COLOR")
            row["browser_ndvi"] = browser_link(
                clat, clon, date, dataset, "3_NDVI")
        results.append(row)

    print(f"\n{len(results)} acquisition(s) {coll} "
          f"du {a.dt_from} au {a.dt_to} (bbox {bbox})\n")
    for r in results:
        cc = (f"  nuages {r['nuages_pct']:.0f}%"
              if r["nuages_pct"] is not None else "")
        print(f"  {r['date']}{cc}\n    {r['produit']}\n"
              f"    Browser : {r['browser_true_color']}\n")

    if a.json_out:
        with open(a.json_out, "w") as fh:
            json.dump(results, fh, indent=2, ensure_ascii=False)
        print(f"JSON écrit : {a.json_out}")


if __name__ == "__main__":
    main()
